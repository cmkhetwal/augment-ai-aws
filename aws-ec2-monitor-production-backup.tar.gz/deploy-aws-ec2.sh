#!/bin/bash

set -e

echo "🚀 Deploying AWS EC2 Monitor on AWS EC2 Instance..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "❌ Error: .env file not found!"
    echo "Please create .env file with your AWS credentials"
    echo "Copy from .env.example and update with your values"
    exit 1
fi

# Load environment variables
export $(cat .env | grep -v '^#' | xargs)

echo "✅ Environment variables loaded"
echo "📊 AWS Region: ${AWS_REGION:-us-east-1}"

# Initialize Docker Swarm if not already initialized
if ! docker info | grep -q "Swarm: active"; then
    echo "🔧 Initializing Docker Swarm..."
    docker swarm init --advertise-addr $(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)
fi

# Remove existing stack if running
echo "🧹 Cleaning up existing deployment..."
docker stack rm aws-monitor 2>/dev/null || true
sleep 15

# Build images
echo "📦 Building Docker images..."
docker build -t aws-monitor-backend:latest ./backend
docker build -t aws-monitor-frontend:latest ./frontend

# Create overlay network
echo "🌐 Creating overlay network..."
docker network rm monitoring-network 2>/dev/null || true
docker network create --driver overlay --attachable monitoring-network

# Deploy the stack
echo "🚀 Deploying the stack..."
docker stack deploy -c docker-stack-aws.yml aws-monitor

echo "📊 Stack deployment initiated. Waiting for services..."
sleep 45

# Check service status
echo "🔍 Service Status:"
docker stack services aws-monitor

echo ""
echo "📊 Detailed Status:"
docker stack ps aws-monitor

# Test endpoints
echo ""
echo "🧪 Testing endpoints..."

# Wait for services to be fully ready
sleep 30

# Test direct backend
echo "Testing backend directly on port 3001..."
if timeout 10 curl -s http://localhost:3001/api/health; then
    echo "✅ Backend direct access working"
else
    echo "❌ Backend direct access failed"
fi

# Test through nginx
echo "Testing through nginx on port 80..."
if timeout 10 curl -s http://localhost/api/health; then
    echo "✅ Nginx proxy working"
else
    echo "❌ Nginx proxy failed"
fi

# Get instance information
echo ""
echo "📊 AWS Information:"
curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null && echo " - Public IP" || echo "Private instance"
curl -s http://169.254.169.254/latest/meta-data/placement/region 2>/dev/null && echo " - Region" || echo ""

echo ""
echo "✅ Deployment completed!"
echo ""
echo "🌟 Access Points (replace 'localhost' with your EC2 public IP):"
echo "   📱 Dashboard: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo 'YOUR-EC2-IP')/"
echo "   🔧 API: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo 'YOUR-EC2-IP')/api/health"
echo ""
echo "🔧 Debug Commands:"
echo "   docker stack services aws-monitor"
echo "   docker service logs aws-monitor_backend"
echo "   docker service logs aws-monitor_nginx-proxy"